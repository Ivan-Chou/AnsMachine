def receiveCmd(command):
	return "指令系統即將推出，敬請期待"
	#cmdParts = []
	#for i in range(0, len(command.split(" "))):
	#	cmdParts.append(command[1:].split(" ")[i])