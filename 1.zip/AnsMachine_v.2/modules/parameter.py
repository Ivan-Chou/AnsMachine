#=======================================<使用者設定>

ProduceLog = True
# 把錯題報告存成文字檔       預設為開啟(True) 
# ※ 錯題報告(WrongLog.txt)設定為"以最新的資料覆蓋上去"，
#    如果想記錄每一次的錯題，請 將檔案改名 或 複製到另外一個檔案 或 放在另一個資料夾

QuizRandomly = False
# 隨機題目順序              預設為關閉(False)
# ※ 固定順序出題有助於背題
#    在設置為True後可以模擬考試隨機出題的感覺

#=======================================</使用者設定>

#=======================================<管理者>

Begin = 1
# 第一個章節是第幾章         預設為1

End = 8
# 最後一章是第幾章           預設為8

#=======================================</管理者>

# programmer log (users can ignore it)
# 1.this file need to be re-realized by json
# 2.package every "input()" function(maybe "sth.cell()" as well)