#===============================<import>

import os
import sys
import adminCommand as cmd
import commonMove as mv
import parameter as para
import openpyxl
import random

#===============================</import>

#===============================<prep>

if(sys.platform == "win32"):
    os.system("color")
os.chdir("..")
os.chdir("questions")

#===============================</prep>

#===============================<def>

ans = 1
Qnum = 2
ques = 3
# Sel : A = 4,B = 5,C = 6,D = 7
expla = 8
BorderLine = 9
QTotalOfPart = 10

#===============================</def>

#===============================<Intro>

print("\033[33m")
print("歡迎使用國防試題答題機。\n \n以下是作答說明：\n")
print("1.是非題：可以使用字母「O」(或「o」)與數字「1」來代表「圈」；並可以使用字母「X」(或「x」)與數字「2」來代表「叉」。\n")
print("2.選擇題：可以使用字母(大小寫皆可)與數字1 2 3 4來分別表示A B C D。\n")
print("3.有非文字選項的題目將會被獨立放在另一個檔案中，請不要忘記也要練習那些題目喔！\n")
print("此外，如果需要中斷作答，也可以在作答的過程中隨時輸入數字「0」以結束作答機\n")
print("那麼。現在開始作答！！\n")
print("\033[0m")

#===============================</Intro>

#===============================<chapter check>

B = 0
E = 0
while (B<para.Begin)or(B>para.End):
    B = int(input("請先輸入你想要從第幾篇的題目開始。\n請輸入開始篇數(阿拉伯數字)："))
print("\n")
while (E<para.Begin)or(E>para.End):
    E = int(input("再輸入你想要做到第幾篇的題目為止。\n請輸入結束篇數(阿拉伯數字)："))
print("\n")

#===============================</chapter check>

wrongQs = []
for chNow in range(B, E+1):
    print("※隨時在作答欄中輸入0以跳出答題※\n")
    FName = "ch" + str(chNow) + ".xlsx"
    file = openpyxl.load_workbook(FName)
    sht = file.worksheets[0]
    rowNow = 1
    
    for part in range(0,2): # 是非 & 選擇
        NowOn = 1
        if para.QuizRandomly:
            print("\033[46m※\t有一些題目由於原檔編號上的問題，可能會有混插的現象，請注意！\t※\033[0m")
            QsOfPartNow = int(sht.cell(row = part+2, column = QTotalOfPart).value)
            BorderOfPartNow = int(sht.cell(row = part+2, column = BorderLine).value)
            Qleft = []
            for x in range(1, QsOfPartNow+1):
                Qleft.append(x)
            
        while True:
        # preparation
            if para.QuizRandomly:
                if len(Qleft) == 0:
                    break
                rowNow = BorderOfPartNow
                QNumNow = random.choice(Qleft)
                Qleft.remove(QNumNow)
                while str(sht.cell(row = rowNow, column = Qnum).value) != str(QNumNow):
                    rowNow += 1
            else:
                rowNow += 1
        
        # case : read nothing -> stop
            article = str(sht.cell(row = rowNow, column = ques).value)
            if article == "None":
                break
            
        # case : a question
            realAns = str(sht.cell(row = rowNow, column = ans).value)
            if realAns != "None":
                print("------------------------------------------------------------------------------------------------------")
                print(str(NowOn)+"."+article)
                if (realAns != "○")and(realAns != "Ｘ"):
                    print("\n")
                    for choose in range(4,8):
                        print(sht.cell(row = rowNow, column = choose).value)
                guess = input("你的答案是：")
                if guess == "0":
                    break
                if (len(guess)!=0)and(guess[0] == '/'):
                    cmd.receiveCmd(guess)
                if mv.checkAns(realAns, guess):
                    print("\033[42m回答正確！！\033[0m")
                else:
                    print("\033[41m回答錯了，正確答案是", realAns, "\033[0m")
                    Qcode = mv.codeProduce(chNow, str(part+1), realAns, str(sht.cell(row = rowNow, column = Qnum).value))
                    wrongQs.append(Qcode)
                    explanation = str(sht.cell(row = rowNow, column = expla).value)
                    if explanation != "None":
                        print("\033[31;1m" + explanation + "\033[0m")
                NowOn += 1
                
        # case : an information or some other things
            else:
                print(article, "\n")

        if part != 1:
            if input("\n此部分作答完畢\n要跳出作答機嗎？(輸入0以跳出作答；任何非0內容以繼續作答)\n") == "0":
                break
    
    if chNow != E:    
        if input("\n此章節作答完畢\n要跳出作答機嗎？(輸入0以跳出作答；任何非0內容以繼續作答)\n") == "0":
            break
    file.close()

print("\n※\t作答結束\t※\n")
print("你這一次做錯的題目有：\033[36;1m\n")
if len(wrongQs) == 0:
    print("沒有做錯任何題目！！恭喜全對！！\n")
else:
    if para.ProduceLog:
        os.chdir("..")
        os.system("date /t> WrongLog.txt")
        f = open("WrongLog.txt", "a", encoding="ms950")
        print("※\t錯題記錄已寫入檔案，請到 WrongLog(.txt) 查看\t※\n(題號為Excel表內編號)\n")
        f.write("\n")
    for Q in wrongQs:
        print(Q)
        if para.ProduceLog:
            f.write(Q)
            f.write("\n")
    if para.ProduceLog:
        f.close()
    print("\033[37m\n記得再回去看看做錯的題目喔！\n")
print("\033[35m※\t不要忘記去做選項不是文字的那些題目喔！\t※\n\033[0m")

#===============================</Main part>