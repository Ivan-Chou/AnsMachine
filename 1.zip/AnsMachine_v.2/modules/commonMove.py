def checkAns(realAns, inputAns):
    if inputAns == realAns:
        return True
    elif realAns == "○":
        if (inputAns == "O") or (inputAns == "o") or (inputAns ==  "1"):
            return True
    elif realAns == "Ｘ":
        if (inputAns == "X") or (inputAns == "x") or (inputAns ==  "2"):
            return True
    elif realAns == "Ａ":
        if (inputAns == "A") or (inputAns == "a") or (inputAns ==  "1"):
            return True
    elif realAns == "Ｂ":
        if (inputAns == "B") or (inputAns == "b") or (inputAns ==  "2"):
            return True
    elif realAns == "Ｃ":
        if (inputAns == "C") or (inputAns == "c") or (inputAns ==  "3"):
            return True
    elif realAns == "Ｄ":
        if (inputAns == "D") or (inputAns == "d") or (inputAns ==  "4"):
            return True
    else:
        return False

def codeProduce(chap, part, ans, Qnum):
	if (ans == "○") or (ans == "Ｘ"):
		Qtype = "是非"
	else:
		Qtype = "選擇"
	r = "第" + str(chap) + "篇 - 第" + part + "部分(" + Qtype + ") - " + Qnum
	return r