import os
import parameter as para
import openpyxl

#============================<function>
def devideString(MotherString):
	words = []
	subStringBegin = 0
	for i in range(0, len(MotherString)):
		if MotherString[i] == "(":
			if(MotherString[i+1] == "A")or(MotherString[i+1] == "B")or(MotherString[i+1] == "C")or(MotherString[i+1] == "D"):
				words.append(MotherString[subStringBegin:i])
				subStringBegin = i
	words.append(MotherString[subStringBegin:])
	return words

def removeQNum(s):
	index = 0
	while s[index] != ".":
		index += 1
	return s[index+1:]
			
#============================</function>
os.chdir("..")
os.chdir("questions")
os.chdir("TXT")
for chNum in range(1, para.End+1):
	filename = "ch" + str(chNum)
	Qtxt = open(filename + ".txt" ,"r", encoding = "utf-8")
	Qxl = openpyxl.Workbook()
	sht = Qxl.worksheets[0]

	#start to copy datas into Exl
	sht["A1"] = "答案"
	sht["B1"] = "題號"
	sht["C1"] = "題目(或敘述說明)"
	sht["D1"] = "(A)選項"
	sht["E1"] = "(B)選項"
	sht["F1"] = "(C)選項"
	sht["G1"] = "(D)選項"
	sht["H1"] = "解析"
	sht["I1"] = "分界(起點)行數"
	sht["J1"] = "是非/選擇 題數"
	row = 2
	rowOfI = 2
	Qlast = 0

	while True:
		article = Qtxt.readline()
	
	# case : read nothing -> stop
		if len(article) == 0:
			break
	
	# case : a question
		if article[0] == "（":
			# answer => A (column)
			ans = article.split(" ")[1]
			sht["A"+str(row)] = ans
			sWithNum = article[5:]
			# number => B
			Qnum = int(sWithNum.split(".")[0])
			if Qnum == 1:
				sht["I"+str(rowOfI)] = row - 1
				rowOfI += 1
				if Qlast != 0:
					sht["J2"] = Qlast
			sht["B"+str(row)] = Qnum
			if (Qnum == 1)or(Qnum > Qlast):
				Qlast = Qnum
			# remove the number
			s = removeQNum(sWithNum)
			# question body => C；selections => D, E, F, G (if exists)
			if(ans =="Ｘ")or(ans =="○"):
				sht["C"+str(row)] = s
			else:
				sBeCut = devideString(s)
				sht["C"+str(row)] = sBeCut[0]
				sht["D"+str(row)] = sBeCut[1]
				sht["E"+str(row)] = sBeCut[2]
				sht["F"+str(row)] = sBeCut[3]
				sht["G"+str(row)] = sBeCut[4]
			
	# case : an explanation => H  ※ Since VAR "row" goes forward each times, need to go back so it can be written at the correct line ※
		elif article[0] == "【":
			row -= 1                         # back to previous question
			sht["H"+str(row)] = article
	
	# case : an information or some other things => C
		else:
			sht["C"+str(row)] = article
		
		row += 1
	sht["J3"] = Qlast

	os.chdir("..")
	Qxl.save(filename + ".xlsx")
	os.chdir("TXT")
	
	Qtxt.close()